# Ristorante Alleria - Sirmione

Sito web del Ristorante Alleria, situato nel cuore di Sirmione sul Lago di Garda.

## 🚀 Deploy su GitHub Pages

Questo sito è ottimizzato per essere deployato su GitHub Pages.

### File inclusi:
- `index.html` - Sito completo con CSS e JavaScript integrati
- Design responsive per mobile e desktop
- Animazioni smooth e interazioni moderne

### Deploy rapido:
1. Carica i file su GitHub
2. Vai in Settings → Pages
3. Seleziona il branch main/master
4. Il sito sarà online in pochi minuti

## 🎨 Caratteristiche
- Design "Sera d'Estate" con palette Navy/Gold/Pearl
- Sezioni: Hero, Experience, Menu, Reviews, Location
- Prenotazioni integrate con Google Maps
- Recensioni TripAdvisor
- Mappe interattive

## 📞 Contatti
- Via Roma, 66 - 25019 Sirmione (BS)
- +39 030 990 6152
- info@ristorantealleria.com
